import React from "react";


export default function User({user, onRemove, onToggle}) {
    return(
        <div>
            <b
                style={{cursor: 'pointer,',
                color: user.active ? 'green' : 'black'    
                }}
                onClick={() => onToggle(user.id)}
            >
                {user.username}
            </b>
            &nbsp;
            <span>({user.email})</span>
            <button onClick={() => onRemove(user.id)}>Delete</button>
        </div>
    );
}